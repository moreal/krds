# Third-party notices: @unofficial-krds/vue

No third-party material is copied or bundled in this package at this snapshot. External dependencies retain their own package notices.
